package com.mygdx.game.actors;

public class ActorDamage extends ActorBase{

    public void damage(float angle){
        super.kill();
    }

}
