package com.mygdx.game.screens;

public class MenuScreen {
}
