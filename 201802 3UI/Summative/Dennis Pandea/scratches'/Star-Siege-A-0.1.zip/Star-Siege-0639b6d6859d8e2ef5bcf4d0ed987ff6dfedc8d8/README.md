# Star-Siege


## Concept:
A game where you mine asteroids and use resources to buy weapons to destroy Aliens and their bases

-------
You start with a main base, a mining laser, and a basic plasma gun. Your goal is to mine the asteroids and sell resources you get from them. With the money you make you can upgrade your weapons, laser, base, or ship.
