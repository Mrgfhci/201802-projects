<?xml version="1.0" encoding="UTF-8"?>
<tileset name="AsteroidMap" tilewidth="64" tileheight="64" tilecount="5" columns="5">
 <image source="AsteroidMap.png" width="320" height="64"/>
 <tile id="0" probability="60"/>
 <tile id="1" probability="10"/>
 <tile id="2" probability="3"/>
 <tile id="3" probability="3"/>
 <tile id="4" probability="4500"/>
</tileset>
